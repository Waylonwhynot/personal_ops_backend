'use strict'
module.exports = {
  NODE_ENV: '"production"',
  BASE_API: '"http://120.78.83.118:8081"'
}
