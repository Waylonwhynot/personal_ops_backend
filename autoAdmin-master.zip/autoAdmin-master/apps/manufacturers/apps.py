from django.apps import AppConfig


class ManufacturersConfig(AppConfig):
    name = 'manufacturers'
