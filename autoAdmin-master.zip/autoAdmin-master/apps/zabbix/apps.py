from django.apps import AppConfig


class ZabbixConfig(AppConfig):
    name = 'zabbix'
